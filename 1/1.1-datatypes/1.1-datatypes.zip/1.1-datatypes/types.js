/* string*/
let name1 = " Rachel Baruh";
/*number*/
let age = 35.5;
/*object*/
let person = {
    firstName: 'rachel',
    lastName: 'Baruh',
    yearOfExprience: 1
};
/*undifined*/
let dog;
/*bool*/
const position = true;
/*null*/
const someNull = null;

console.log(name1);
console.log(age);
console.log(person);
console.log(position);
console.log(dog);
console.log(someNull);